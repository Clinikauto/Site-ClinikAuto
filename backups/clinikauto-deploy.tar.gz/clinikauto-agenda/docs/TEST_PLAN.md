# Test Plan

## Rendez-vous

1. Ajouter un rendez-vous valide depuis admin.html.
2. Tenter de réserver le même créneau: rejet attendu.
3. Modifier un rendez-vous puis confirmer.
4. Supprimer un rendez-vous.

## Vroomly

1. Déclencher un export CSV.
2. Déclencher un export JSON.
3. Vérifier `src/logs/export_vroomly.log`.
4. Si `VROOMLY_ENDPOINT_URL` est configuré, vérifier le code HTTP de retour.

## Droits

1. Visiteur: popup index puis redirection vers register.
2. Client: accès à espace-client avec créneaux uniquement.
3. Admin: accès complet à admin.html.
4. Admin: changement de rôle utilisateur.

## Google Calendar

1. Connecter OAuth Google.
2. Vérifier la remontée des événements dans admin.
3. Ajouter/modifier/supprimer un rendez-vous et contrôler la synchronisation distante.

## Sauvegarde locale

1. Appeler `src/api/sync_local.php`.
2. Vérifier la création d’un fichier dans `src/data/backups`.
3. Vérifier `src/logs/sync_local.log`.
