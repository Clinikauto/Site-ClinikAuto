# API Reference

## Auth

### GET `src/client/auth.php?action=session`
Retourne l’état de session courant, le rôle et le token CSRF.

### GET `src/client/auth.php?action=csrf`
Retourne un jeton CSRF pour les appels POST.

### POST `src/client/auth.php?action=login`
Body JSON: `email`, `password`

### POST `src/client/auth.php?action=register`
Body JSON: `email`, `password`

### POST `src/client/auth.php?action=logout`
Header: `X-CSRF-Token`

### GET `src/client/auth.php?action=users`
Admin only. Liste les utilisateurs.

### POST `src/client/auth.php?action=update-role`
Admin only. Body JSON: `user_id`, `role`

### GET `src/client/auth.php?action=google-login`
Démarre OAuth Google.

### GET `src/client/auth.php?action=google-callback`
Callback OAuth Google.

## Agenda

### GET `src/admin/agenda.php?action=list`
Admin only. Liste les rendez-vous.

### GET `src/admin/agenda.php?action=slots&days=7`
Renvoie les créneaux disponibles sur `days` jours.

### POST `src/admin/agenda.php?action=create`
Admin only. Body JSON: `date`, `time`, `client_id`, `status`, `notes`

### POST `src/admin/agenda.php?action=update`
Admin only. Body JSON: `id`, `date`, `time`, `client_id`, `status`, `notes`

### POST `src/admin/agenda.php?action=confirm`
Admin only. Body JSON: `id`

### POST `src/admin/agenda.php?action=delete`
Admin only. Body JSON: `id`

### GET `src/admin/agenda.php?action=google-events`
Admin only. Renvoie les 20 prochains événements Google Calendar.

## Exports et synchro

### GET `src/api/export_vroomly.php?format=csv|json`
Admin only. Génère les exports CSV/JSON et tente l’envoi POST vers l’endpoint Vroomly configuré.

### GET `src/api/sync_local.php`
Admin only (ou CLI). Sauvegarde `agenda.db` dans `src/data/backups` puis tente une synchronisation distante.
