# Installation

## Prérequis

- PHP 8.1+
- Composer
- Extension SQLite activée
- Compte Google Cloud avec API Google Calendar activée

## Étapes

1. Copier `.env.example` vers `.env`.
2. Renseigner `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`.
3. Exécuter `composer install` à la racine du projet.
4. Servir `src/public` avec Apache/Nginx ou le serveur web PHP.
5. Ouvrir `src/public/index.html` ou la route publique configurée.

## OAuth Google Agenda

1. Créer un projet Google Cloud.
2. Activer l’API Google Calendar.
3. Créer un identifiant OAuth 2.0 de type application web.
4. Ajouter comme URI de redirection la valeur `GOOGLE_REDIRECT_URI`.
5. Se connecter en admin puis cliquer `Connecter Google Agenda`.

## Synchronisation locale

- Lancer `src/api/sync_local.php` via cron ou Tâches planifiées.
- Recommandation: toutes les 15 minutes.

## Sécurité

- Les mots de passe sont hashés via bcrypt.
- Les mutations critiques exigent un jeton CSRF.
- Les sessions PHP sont `HttpOnly` et `SameSite=Lax`.
- Les secrets restent dans `.env`, ignoré par Git.

## Vérifications minimales

- Connexion admin
- Création / édition / suppression / confirmation d’un rendez-vous
- Export CSV/JSON Vroomly
- Accès client aux seuls créneaux disponibles
- Changement de rôle utilisateur depuis l’admin
