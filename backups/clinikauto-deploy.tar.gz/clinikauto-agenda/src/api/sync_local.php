<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/admin/config.php';

function backup_database_file(): array
{
    $source = data_path('agenda.db');
    $backupDir = data_path('backups');
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0775, true);
    }

    if (!is_file($source)) {
        throw new RuntimeException('Base locale introuvable');
    }

    $backupName = 'agenda-' . date('Ymd-His') . '.db';
    $target = $backupDir . DIRECTORY_SEPARATOR . $backupName;
    if (!copy($source, $target)) {
        throw new RuntimeException('Sauvegarde impossible');
    }

    return [
        'source' => $source,
        'backup' => $target,
        'size' => filesize($target) ?: 0,
    ];
}

function push_backup_to_remote(array $backup): array
{
    $targetUrl = env('SYNC_TARGET_URL');
    $targetToken = env('SYNC_TARGET_TOKEN');

    if (!$targetUrl) {
        audit_log('sync_backup_skipped', ['reason' => 'missing_target_url'], 'sync_local.log');
        return ['status' => 'skipped', 'message' => 'Aucune cible distante configurée'];
    }

    $payload = json_encode([
        'filename' => basename($backup['backup']),
        'size' => $backup['size'],
        'generated_at' => date(DATE_ATOM),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $headers = [
        'Content-Type: application/json',
        'Content-Length: ' . strlen((string) $payload),
    ];
    if ($targetToken) {
        $headers[] = 'Authorization: Bearer ' . $targetToken;
    }

    $result = ['status' => 'skipped', 'message' => 'Transport non exécuté'];
    if (function_exists('curl_init')) {
        $ch = curl_init($targetUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
        ]);
        $response = (string) curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_errno($ch) ? curl_error($ch) : null;
        curl_close($ch);

        $result = [
            'status' => (!$error && $httpCode >= 200 && $httpCode < 300) ? 'success' : 'error',
            'http_code' => $httpCode,
            'message' => $error ?: 'Réponse distante reçue',
            'response' => mb_substr($response, 0, 500),
        ];
    }

    audit_log('sync_backup_result', $result, 'sync_local.log');
    return $result;
}

try {
    if (PHP_SAPI !== 'cli') {
        require_auth('admin');
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            verify_csrf();
        }
    }

    $backup = backup_database_file();
    $push = push_backup_to_remote($backup);

    json_response([
        'message' => 'Synchronisation locale exécutée',
        'backup' => [
            'file' => basename($backup['backup']),
            'size' => $backup['size'],
        ],
        'remote' => $push,
        'schedule_hint' => 'Planifier ce script via cron ou Tâches planifiées toutes les 15 minutes.',
    ]);
} catch (Throwable $exception) {
    audit_log('sync_backup_error', ['message' => $exception->getMessage()], 'sync_local.log');
    json_response(['error' => $exception->getMessage()], 500);
}
