<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/admin/config.php';

function generate_vroomly_exports(PDO $pdo): array
{
    $stmt = $pdo->query(
        "SELECT a.id, a.date, a.status, a.notes, u.email
         FROM appointments a
         LEFT JOIN users u ON u.id = a.client_id
         ORDER BY a.date ASC"
    );
    $rows = $stmt->fetchAll();
    $entries = array_map('export_row_from_appointment', $rows ?: []);

    $exportsDir = data_path('exports');
    if (!is_dir($exportsDir)) {
        mkdir($exportsDir, 0775, true);
    }

    $csvPath = $exportsDir . DIRECTORY_SEPARATOR . 'vroomly_latest.csv';
    $jsonPath = $exportsDir . DIRECTORY_SEPARATOR . 'vroomly_latest.json';

    $fp = fopen($csvPath, 'wb');
    fputcsv($fp, ['date', 'time', 'client', 'status', 'notes']);
    foreach ($entries as $entry) {
        fputcsv($fp, [$entry['date'], $entry['time'], $entry['client'], $entry['status'], $entry['notes']]);
    }
    fclose($fp);

    file_put_contents($jsonPath, json_encode($entries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

    return [
        'csv_path' => $csvPath,
        'json_path' => $jsonPath,
        'count' => count($entries),
        'rows' => $entries,
    ];
}

function push_vroomly_export(array $export): array
{
    $endpoint = env('VROOMLY_ENDPOINT_URL');
    $token = env('VROOMLY_API_TOKEN');

    if (!$endpoint) {
        $result = ['status' => 'skipped', 'message' => 'Aucun endpoint Vroomly configuré'];
        audit_log('vroomly_export_skipped', $result + ['count' => $export['count']], 'export_vroomly.log');
        return $result;
    }

    $payload = json_encode([
        'generated_at' => date(DATE_ATOM),
        'count' => $export['count'],
        'appointments' => $export['rows'],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $headers = [
        'Content-Type: application/json',
        'Content-Length: ' . strlen((string) $payload),
    ];
    if ($token) {
        $headers[] = 'Authorization: Bearer ' . $token;
    }

    $httpCode = 0;
    $responseBody = '';
    $errorMessage = null;

    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
        ]);
        $responseBody = (string) curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_errno($ch)) {
            $errorMessage = curl_error($ch);
        }
        curl_close($ch);
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $headers),
                'content' => $payload,
                'timeout' => 15,
            ]
        ]);
        $responseBody = (string) @file_get_contents($endpoint, false, $context);
        $httpCode = 200;
        if ($responseBody === '') {
            $errorMessage = 'Transport HTTP indisponible';
        }
    }

    $success = !$errorMessage && $httpCode >= 200 && $httpCode < 300;
    $result = [
        'status' => $success ? 'success' : 'error',
        'http_code' => $httpCode,
        'message' => $success ? 'Export envoyé' : ($errorMessage ?: 'Réponse distante invalide'),
        'response' => mb_substr($responseBody, 0, 500),
    ];

    audit_log($success ? 'vroomly_export_success' : 'vroomly_export_error', $result + ['count' => $export['count']], 'export_vroomly.log');
    return $result;
}

function run_vroomly_export(PDO $pdo, string $reason = 'manual'): array
{
    $export = generate_vroomly_exports($pdo);
    $push = push_vroomly_export($export);
    audit_log('vroomly_export_generated', ['reason' => $reason, 'count' => $export['count']], 'export_vroomly.log');

    return [
        'generated' => [
            'count' => $export['count'],
            'csv' => basename($export['csv_path']),
            'json' => basename($export['json_path']),
        ],
        'push' => $push,
    ];
}

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    $user = require_auth('admin');
    $pdo = get_pdo();
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        verify_csrf();
    }

    $format = $_GET['format'] ?? 'json';
    $result = run_vroomly_export($pdo, 'manual_http');

    if ($format === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="vroomly_latest.csv"');
        readfile(data_path('exports/vroomly_latest.csv'));
        exit;
    }

    json_response([
        'message' => 'Export Vroomly déclenché',
        'result' => $result,
        'user' => $user['email'] ?? null,
    ]);
}
