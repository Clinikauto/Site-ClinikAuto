<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/admin/config.php';

$pdo = get_pdo();
$action = $_GET['action'] ?? 'session';

function login_user(PDO $pdo, string $email, string $password): void
{
    $stmt = $pdo->prepare('SELECT id, email, password_hash, role FROM users WHERE email = :email LIMIT 1');
    $stmt->execute(['email' => mb_strtolower(trim($email))]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        audit_log('login_failed', ['email' => $email, 'ip' => $_SERVER['REMOTE_ADDR'] ?? 'cli']);
        json_response(['error' => 'Identifiants invalides'], 401);
    }

    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id' => (int) $user['id'],
        'email' => $user['email'],
        'role' => $user['role'],
    ];

    audit_log('login_success', ['email' => $user['email'], 'role' => $user['role']]);
    json_response([
        'message' => 'Connexion réussie',
        'user' => $_SESSION['user'],
        'csrf_token' => csrf_token(),
    ]);
}

function register_user(PDO $pdo, string $email, string $password): void
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_response(['error' => 'Email invalide'], 422);
    }
    if (mb_strlen($password) < 8) {
        json_response(['error' => 'Mot de passe trop court'], 422);
    }

    $stmt = $pdo->prepare('INSERT INTO users(email, password_hash, role) VALUES(:email, :password_hash, :role)');
    try {
        $stmt->execute([
            'email' => mb_strtolower(trim($email)),
            'password_hash' => password_hash($password, PASSWORD_BCRYPT),
            'role' => 'client',
        ]);
    } catch (PDOException $exception) {
        json_response(['error' => 'Compte déjà existant'], 409);
    }

    audit_log('register_success', ['email' => $email]);
    json_response(['message' => 'Compte créé avec succès']);
}

function list_users(PDO $pdo): void
{
    require_auth('admin');
    $rows = $pdo->query('SELECT id, email, role, created_at FROM users ORDER BY role DESC, email ASC')->fetchAll();
    json_response(['users' => $rows]);
}

function update_user_role(PDO $pdo, int $userId, string $role): void
{
    $admin = require_auth('admin');
    if (!in_array($role, ['admin', 'client'], true)) {
        json_response(['error' => 'Rôle invalide'], 422);
    }

    $stmt = $pdo->prepare('UPDATE users SET role = :role WHERE id = :id');
    $stmt->execute(['role' => $role, 'id' => $userId]);
    audit_log('role_updated', ['target_user_id' => $userId, 'role' => $role, 'by' => $admin['email']]);
    json_response(['message' => 'Rôle mis à jour']);
}

function google_login(): void
{
    $user = require_auth('admin');
    $client = google_client();
    if (!$client) {
        json_response(['error' => 'Google OAuth non configuré. Vérifiez .env et composer install.'], 503);
    }

    $client->setState(bin2hex(random_bytes(16)));
    $_SESSION['google_oauth_state'] = $client->getState();
    audit_log('google_oauth_start', ['by' => $user['email']]);
    header('Location: ' . $client->createAuthUrl());
    exit;
}

function google_callback(): void
{
    $client = google_client();
    if (!$client) {
        exit('Google OAuth non configuré.');
    }

    $state = $_GET['state'] ?? '';
    if (!$state || !hash_equals($_SESSION['google_oauth_state'] ?? '', $state)) {
        exit('État OAuth invalide.');
    }

    $code = $_GET['code'] ?? '';
    if ($code === '') {
        exit('Code OAuth manquant.');
    }

    $token = $client->fetchAccessTokenWithAuthCode($code);
    if (isset($token['error'])) {
        exit('Erreur OAuth Google: ' . htmlspecialchars((string) $token['error'], ENT_QUOTES, 'UTF-8'));
    }

    $_SESSION['google_token'] = $token;
    audit_log('google_oauth_connected', ['email' => current_user()['email'] ?? 'unknown']);
    header('Location: ../admin/admin.html?google=connected');
    exit;
}

switch ($action) {
    case 'csrf':
        json_response(['csrf_token' => csrf_token()]);
        break;

    case 'session':
        json_response([
            'authenticated' => current_user() !== null,
            'user' => current_user(),
            'csrf_token' => csrf_token(),
            'google_connected' => !empty($_SESSION['google_token']),
        ]);
        break;

    case 'login':
        verify_csrf();
        $body = request_json();
        login_user($pdo, (string) ($body['email'] ?? ''), (string) ($body['password'] ?? ''));
        break;

    case 'register':
        verify_csrf();
        $body = request_json();
        register_user($pdo, (string) ($body['email'] ?? ''), (string) ($body['password'] ?? ''));
        break;

    case 'logout':
        verify_csrf();
        audit_log('logout', ['email' => current_user()['email'] ?? null]);
        $_SESSION = [];
        session_destroy();
        json_response(['message' => 'Déconnecté']);
        break;

    case 'users':
        list_users($pdo);
        break;

    case 'update-role':
        verify_csrf();
        $body = request_json();
        update_user_role($pdo, (int) ($body['user_id'] ?? 0), (string) ($body['role'] ?? 'client'));
        break;

    case 'google-login':
        google_login();
        break;

    case 'google-callback':
        google_callback();
        break;

    default:
        json_response(['error' => 'Action inconnue'], 404);
}
