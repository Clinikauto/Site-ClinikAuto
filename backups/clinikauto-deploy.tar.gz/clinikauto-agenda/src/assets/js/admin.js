let adminState = { appointments: [], users: [], csrfToken: '' };

function formatDateTime(value) {
  const date = new Date(value.replace(' ', 'T'));
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('fr-FR');
}

function renderAppointments() {
  const search = document.getElementById('searchInput').value.trim().toLowerCase();
  const filter = document.getElementById('statusFilter').value;
  const tbody = document.getElementById('appointmentsBody');

  const filtered = adminState.appointments.filter((item) => {
    const haystack = [item.email || '', item.notes || '', item.date || ''].join(' ').toLowerCase();
    const bySearch = !search || haystack.includes(search);
    const byStatus = filter === 'all' || item.status === filter;
    return bySearch && byStatus;
  });

  tbody.innerHTML = filtered.map((item) => `
    <tr>
      <td>${formatDateTime(item.date)}</td>
      <td>${item.email || 'Non assigné'}</td>
      <td><span class="${badgeClass(item.status)}">${item.status}</span></td>
      <td>${item.notes || ''}</td>
      <td>
        <button class="btn btn-secondary" data-edit="${item.id}">Modifier</button>
        <button class="btn btn-success" data-confirm="${item.id}">Confirmer</button>
        <button class="btn btn-danger" data-delete="${item.id}">Supprimer</button>
      </td>
    </tr>
  `).join('');
}

function renderUsers() {
  const tbody = document.getElementById('usersBody');
  tbody.innerHTML = adminState.users.map((user) => `
    <tr>
      <td>${user.email}</td>
      <td>${user.role}</td>
      <td>
        <select data-role-user="${user.id}">
          <option value="client" ${user.role === 'client' ? 'selected' : ''}>client</option>
          <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>admin</option>
        </select>
      </td>
    </tr>
  `).join('');
}

async function loadAdminData() {
  const [appointmentsPayload, usersPayload] = await Promise.all([
    fetchJson('agenda.php?action=list'),
    fetchJson('../client/auth.php?action=users'),
  ]);
  adminState.appointments = appointmentsPayload.appointments || [];
  adminState.users = usersPayload.users || [];
  renderAppointments();
  renderUsers();
}

async function submitAppointmentForm(event) {
  event.preventDefault();
  const id = document.getElementById('appointmentId').value;
  const payload = {
    id: id ? Number(id) : undefined,
    date: document.getElementById('appointmentDate').value,
    time: document.getElementById('appointmentTime').value,
    client_id: Number(document.getElementById('appointmentClient').value) || null,
    status: document.getElementById('appointmentStatus').value,
    notes: document.getElementById('appointmentNotes').value,
  };

  const action = id ? 'update' : 'create';
  const result = await fetchJson('agenda.php?action=' + action, {
    method: 'POST',
    headers: { 'X-CSRF-Token': adminState.csrfToken },
    body: JSON.stringify(payload),
  });

  document.getElementById('adminStatus').textContent = result.message + ' Export: ' + (result.export?.push?.status || 'n/a');
  event.target.reset();
  document.getElementById('appointmentId').value = '';
  await loadAdminData();
}

async function exportVroomly(format) {
  const response = await fetch('../api/export_vroomly.php?format=' + format, {
    credentials: 'same-origin',
    headers: { 'X-CSRF-Token': adminState.csrfToken },
  });

  if (format === 'csv') {
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'vroomly_latest.csv';
    link.click();
    URL.revokeObjectURL(url);
    document.getElementById('adminStatus').textContent = 'Export CSV généré et téléchargé.';
    return;
  }

  const payload = await response.json();
  document.getElementById('adminStatus').textContent = payload.message;
}

// -----------------------------------------------------------------------
// Google Agenda — CRUD complet
// -----------------------------------------------------------------------

let googleState = { events: [], connected: false };

function formatGoogleDT(raw) {
  if (!raw) return '—';
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? raw : d.toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });
}

/** Convertit une date ISO/locale en valeur pour <input type="datetime-local"> */
function toInputDT(raw) {
  if (!raw) return '';
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return '';
  // format "YYYY-MM-DDTHH:MM" attendu par datetime-local
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Renvoie une chaîne ISO RFC3339 depuis la valeur d'un datetime-local */
function fromInputDT(value) {
  if (!value) return '';
  return new Date(value).toISOString();
}

function renderGoogleEvents() {
  const tbody = document.getElementById('googleEventsBody');
  const statusEl = document.getElementById('googleStatus');

  if (!googleState.connected) {
    tbody.innerHTML = '<tr><td colspan="4" class="muted">Google Agenda non connecté — cliquez sur "Connecter / Reconnecter Google".</td></tr>';
    statusEl.textContent = 'Google Agenda : non connecté.';
    statusEl.className = 'status-note status-note--error';
    return;
  }

  statusEl.textContent = `Google Agenda connecté — ${googleState.events.length} événement(s) à venir.`;
  statusEl.className = 'status-note status-note--ok';

  if (googleState.events.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" class="muted">Aucun événement à venir.</td></tr>';
    return;
  }

  tbody.innerHTML = googleState.events.map((ev) => `
    <tr>
      <td>${escHtml(ev.summary || 'Sans titre')}</td>
      <td>${formatGoogleDT(ev.start)}</td>
      <td>${formatGoogleDT(ev.end)}</td>
      <td>
        <button class="btn btn-secondary" data-gedit="${escHtml(ev.id)}" data-gsummary="${escHtml(ev.summary || '')}" data-gstart="${escHtml(ev.start || '')}" data-gend="${escHtml(ev.end || '')}">Modifier</button>
        <button class="btn btn-danger" data-gdelete="${escHtml(ev.id)}" data-gsummary="${escHtml(ev.summary || '')}">Supprimer</button>
      </td>
    </tr>
  `).join('');
}

function escHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

async function loadGoogleEvents() {
  const payload = await fetchJson('agenda.php?action=google-events');
  googleState.connected = !!payload.connected;
  googleState.events = payload.events || [];
  renderGoogleEvents();
}

function resetGoogleForm() {
  document.getElementById('googleEventId').value = '';
  document.getElementById('googleSummary').value = '';
  document.getElementById('googleStart').value = '';
  document.getElementById('googleEnd').value = '';
  document.getElementById('googleDescription').value = '';
  document.getElementById('googleSubmitBtn').textContent = 'Ajouter dans Google Agenda';
  document.getElementById('googleCancelEditBtn').style.display = 'none';
}

async function submitGoogleEventForm(event) {
  event.preventDefault();
  const id      = document.getElementById('googleEventId').value.trim();
  const summary = document.getElementById('googleSummary').value.trim();
  const start   = fromInputDT(document.getElementById('googleStart').value);
  const end     = fromInputDT(document.getElementById('googleEnd').value);
  const desc    = document.getElementById('googleDescription').value.trim();

  if (!summary || !start || !end) {
    document.getElementById('adminStatus').textContent = 'Titre, début et fin sont requis.';
    return;
  }

  const action  = id ? 'google-update' : 'google-add';
  const payload = { summary, start, end, description: desc };
  if (id) payload.id = id;

  const result = await fetchJson(`agenda.php?action=${action}`, {
    method: 'POST',
    headers: { 'X-CSRF-Token': adminState.csrfToken, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  document.getElementById('adminStatus').textContent = result.message || result.error || 'Opération terminée.';
  resetGoogleForm();
  await loadGoogleEvents();
}

async function deleteGoogleEvent(eventId, summary) {
  if (!confirm(`Supprimer l'événement Google « ${summary} » ?`)) return;
  const result = await fetchJson('agenda.php?action=google-delete', {
    method: 'POST',
    headers: { 'X-CSRF-Token': adminState.csrfToken, 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: eventId }),
  });
  document.getElementById('adminStatus').textContent = result.message || result.error || 'Supprimé.';
  await loadGoogleEvents();
}

async function initAdmin() {
  const session = await getSession();
  if (!session.authenticated || session.user.role !== 'admin') {
    window.location.href = '../public/login.html';
    return;
  }

  adminState.csrfToken = session.csrf_token;
  document.getElementById('adminEmail').textContent = session.user.email;

  const clientSelect = document.getElementById('appointmentClient');
  await loadAdminData();
  clientSelect.innerHTML = '<option value="">Sans client</option>' + adminState.users
    .filter((user) => user.role === 'client')
    .map((user) => `<option value="${user.id}">${user.email}</option>`)
    .join('');

  await loadGoogleEvents();

  document.getElementById('searchInput').addEventListener('input', renderAppointments);
  document.getElementById('statusFilter').addEventListener('change', renderAppointments);
  document.getElementById('appointmentForm').addEventListener('submit', submitAppointmentForm);

  // Google Agenda
  document.getElementById('googleEventForm').addEventListener('submit', submitGoogleEventForm);
  document.getElementById('refreshGoogleBtn').addEventListener('click', loadGoogleEvents);
  document.getElementById('googleCancelEditBtn').addEventListener('click', resetGoogleForm);
  document.getElementById('connectGoogleBtn').addEventListener('click', () => {
    window.location.href = '../client/auth.php?action=google-login';
  });

  document.getElementById('googleEventsBody').addEventListener('click', async (event) => {
    const editId = event.target.dataset.gedit;
    const deleteId = event.target.dataset.gdelete;

    if (editId) {
      document.getElementById('googleEventId').value = editId;
      document.getElementById('googleSummary').value = event.target.dataset.gsummary || '';
      document.getElementById('googleStart').value = toInputDT(event.target.dataset.gstart || '');
      document.getElementById('googleEnd').value = toInputDT(event.target.dataset.gend || '');
      document.getElementById('googleDescription').value = '';
      document.getElementById('googleSubmitBtn').textContent = 'Enregistrer les modifications';
      document.getElementById('googleCancelEditBtn').style.display = '';
      document.getElementById('googleFormWrap').open = true;
      document.getElementById('googleSummary').focus();
      return;
    }

    if (deleteId) {
      await deleteGoogleEvent(deleteId, event.target.dataset.gsummary || deleteId);
    }
  });

  document.getElementById('appointmentsBody').addEventListener('click', async (event) => {
    const editId = event.target.dataset.edit;
    const confirmId = event.target.dataset.confirm;
    const deleteId = event.target.dataset.delete;

    if (editId) {
      const item = adminState.appointments.find((entry) => String(entry.id) === String(editId));
      if (!item) return;
      const [date, time] = item.date.split(' ');
      document.getElementById('appointmentId').value = item.id;
      document.getElementById('appointmentDate').value = date;
      document.getElementById('appointmentTime').value = (time || '').slice(0, 5);
      document.getElementById('appointmentClient').value = item.client_id || '';
      document.getElementById('appointmentStatus').value = item.status;
      document.getElementById('appointmentNotes').value = item.notes || '';
      return;
    }

    if (confirmId) {
      await fetchJson('agenda.php?action=confirm', {
        method: 'POST',
        headers: { 'X-CSRF-Token': adminState.csrfToken },
        body: JSON.stringify({ id: Number(confirmId) }),
      });
      await loadAdminData();
      return;
    }

    if (deleteId && confirm('Supprimer ce rendez-vous ?')) {
      await fetchJson('agenda.php?action=delete', {
        method: 'POST',
        headers: { 'X-CSRF-Token': adminState.csrfToken },
        body: JSON.stringify({ id: Number(deleteId) }),
      });
      await loadAdminData();
    }
  });

  document.getElementById('usersBody').addEventListener('change', async (event) => {
    const userId = event.target.dataset.roleUser;
    if (!userId) return;
    await fetchJson('../client/auth.php?action=update-role', {
      method: 'POST',
      headers: { 'X-CSRF-Token': adminState.csrfToken },
      body: JSON.stringify({ user_id: Number(userId), role: event.target.value }),
    });
    document.getElementById('adminStatus').textContent = 'Droit utilisateur mis à jour.';
    await loadAdminData();
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initAdmin().catch((error) => {
    document.getElementById('adminStatus').textContent = error.message;
  });
});

