async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  });

  const text = await response.text();
  let payload = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch (_error) {
    payload = null;
  }

  if (!response.ok) {
    throw new Error((payload && payload.error) || 'Erreur serveur');
  }

  return payload;
}

async function getSession() {
  return fetchJson('../client/auth.php?action=session');
}

async function getCsrfToken() {
  const payload = await fetchJson('../client/auth.php?action=csrf');
  return payload.csrf_token;
}

function badgeClass(status) {
  switch (status) {
    case 'confirmed': return 'badge badge-confirmed';
    case 'cancelled': return 'badge badge-cancelled';
    default: return 'badge badge-pending';
  }
}
