async function bindLoginForm() {
  const sessionPayload = await fetchJson('../client/auth.php?action=csrf');
  const csrfToken = sessionPayload.csrf_token;
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');

  if (loginForm) {
    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const payload = {
        email: document.getElementById('loginEmail').value,
        password: document.getElementById('loginPassword').value,
      };

      const result = await fetchJson('../client/auth.php?action=login', {
        method: 'POST',
        headers: { 'X-CSRF-Token': csrfToken },
        body: JSON.stringify(payload),
      });

      if (result.user.role === 'admin') {
        window.location.href = '../admin/admin.html';
      } else {
        window.location.href = '../client/espace-client.html';
      }
    });
  }

  if (registerForm) {
    registerForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const payload = {
        email: document.getElementById('registerEmail').value,
        password: document.getElementById('registerPassword').value,
      };

      await fetchJson('../client/auth.php?action=register', {
        method: 'POST',
        headers: { 'X-CSRF-Token': csrfToken },
        body: JSON.stringify(payload),
      });

      window.location.href = 'login.html?registered=1';
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  bindLoginForm().catch((error) => {
    const status = document.getElementById('authStatus');
    if (status) status.textContent = error.message;
  });
});
