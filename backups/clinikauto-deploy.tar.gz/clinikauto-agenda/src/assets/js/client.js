async function initClientSpace() {
  const session = await getSession();
  if (!session.authenticated) {
    window.location.href = '../public/login.html';
    return;
  }

  document.getElementById('clientIdentity').textContent = session.user.email;
  const payload = await fetchJson('../admin/agenda.php?action=slots&days=10');
  const list = document.getElementById('slotsList');
  list.innerHTML = (payload.slots || []).map((slot) => `
    <li class="card">
      <strong>${slot.date}</strong><br>
      <span class="muted">${slot.time}</span>
    </li>
  `).join('');
}

document.addEventListener('DOMContentLoaded', () => {
  initClientSpace().catch((error) => {
    document.getElementById('slotsStatus').textContent = error.message;
  });
});
