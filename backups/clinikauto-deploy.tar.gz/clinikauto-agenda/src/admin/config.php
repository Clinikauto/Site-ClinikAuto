<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_name('clinikauto_admin');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

date_default_timezone_set('Europe/Paris');

function env_load(string $filePath): void
{
    if (!is_file($filePath)) {
        return;
    }

    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!$lines) {
        return;
    }

    foreach ($lines as $line) {
        $trimmed = trim($line);
        if ($trimmed === '' || str_starts_with($trimmed, '#') || !str_contains($trimmed, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $trimmed, 2);
        $key = trim($key);
        $value = trim($value);
        if ($key === '') {
            continue;
        }

        if ((str_starts_with($value, '"') && str_ends_with($value, '"')) || (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
            $value = substr($value, 1, -1);
        }

        $_ENV[$key] = $value;
        $_SERVER[$key] = $value;
        putenv($key . '=' . $value);
    }
}

env_load(dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . '.env');

function env(string $key, ?string $default = null): ?string
{
    $value = $_ENV[$key] ?? $_SERVER[$key] ?? getenv($key);
    if ($value === false || $value === null || $value === '') {
        return $default;
    }
    return (string) $value;
}

function app_url(string $path = ''): string
{
    $base = rtrim(env('APP_URL', 'http://localhost/clinikauto-agenda/src/public'), '/');
    return $base . '/' . ltrim($path, '/');
}

function data_path(string $relative = ''): string
{
    $base = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data';
    return $relative === '' ? $base : $base . DIRECTORY_SEPARATOR . ltrim($relative, DIRECTORY_SEPARATOR);
}

function log_path(string $filename): string
{
    return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . $filename;
}

function get_pdo(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dbPath = data_path('agenda.db');
    if (!is_dir(dirname($dbPath))) {
        mkdir(dirname($dbPath), 0775, true);
    }

    $pdo = new PDO('sqlite:' . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON');

    initialize_database($pdo);
    seed_admin_account($pdo);

    return $pdo;
}

function initialize_database(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'client' CHECK (role IN ('admin', 'client')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            client_id INTEGER,
            status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled')),
            notes TEXT DEFAULT '',
            external_event_id TEXT DEFAULT NULL,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE SET NULL
        )"
    );

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(date)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_appointments_client ON appointments(client_id)");
}

function seed_admin_account(PDO $pdo): void
{
    $adminEmail = mb_strtolower(trim(env('ADMIN_EMAIL', 'clinikauto74@gmail.com') ?? 'clinikauto74@gmail.com'));
    $adminPassword = env('ADMIN_PASSWORD', 'ChangeThisPassword123!') ?? 'ChangeThisPassword123!';

    $stmt = $pdo->prepare('SELECT id, role FROM users WHERE email = :email LIMIT 1');
    $stmt->execute(['email' => $adminEmail]);
    $existing = $stmt->fetch();

    if ($existing) {
        if ($existing['role'] !== 'admin') {
            $update = $pdo->prepare('UPDATE users SET role = :role WHERE id = :id');
            $update->execute(['role' => 'admin', 'id' => $existing['id']]);
        }
        return;
    }

    $insert = $pdo->prepare('INSERT INTO users(email, password_hash, role) VALUES(:email, :password_hash, :role)');
    $insert->execute([
        'email' => $adminEmail,
        'password_hash' => password_hash($adminPassword, PASSWORD_BCRYPT),
        'role' => 'admin',
    ]);
}

function json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function request_json(): array
{
    $raw = file_get_contents('php://input') ?: '';
    if ($raw === '') {
        return $_POST ?: [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
    if (!is_string($token) || $token === '' || !hash_equals(csrf_token(), $token)) {
        audit_log('csrf_failed', ['ip' => $_SERVER['REMOTE_ADDR'] ?? 'cli']);
        json_response(['error' => 'Jeton CSRF invalide'], 419);
    }
}

function current_user(): ?array
{
    return isset($_SESSION['user']) && is_array($_SESSION['user']) ? $_SESSION['user'] : null;
}

function require_auth(?string $requiredRole = null): array
{
    $user = current_user();
    if (!$user) {
        json_response(['error' => 'Authentification requise'], 401);
    }

    if ($requiredRole !== null && ($user['role'] ?? null) !== $requiredRole) {
        json_response(['error' => 'Accès refusé'], 403);
    }

    return $user;
}

function audit_log(string $action, array $context = [], string $filename = 'app.log'): void
{
    $entry = [
        'at' => date(DATE_ATOM),
        'action' => $action,
        'context' => $context,
    ];
    file_put_contents(log_path($filename), json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL, FILE_APPEND);
}

function available_time_slots(): array
{
    return ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'];
}

function normalize_datetime_input(string $date, string $time): string
{
    $date = trim($date);
    $time = trim($time);
    $dt = DateTimeImmutable::createFromFormat('Y-m-d H:i', $date . ' ' . $time);
    if (!$dt) {
        throw new InvalidArgumentException('Date ou heure invalide');
    }
    return $dt->format('Y-m-d H:i:s');
}

function export_row_from_appointment(array $row): array
{
    $dt = new DateTimeImmutable($row['date']);
    return [
        'id' => (int) $row['id'],
        'date' => $dt->format('Y-m-d'),
        'time' => $dt->format('H:i'),
        'client' => $row['email'] ?? 'Non assigné',
        'status' => $row['status'],
        'notes' => (string) ($row['notes'] ?? ''),
    ];
}

function google_client(): ?Google_Client
{
    $autoload = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
    if (!is_file($autoload)) {
        return null;
    }

    require_once $autoload;
    if (!class_exists(Google_Client::class)) {
        return null;
    }

    $clientId = env('GOOGLE_CLIENT_ID');
    $clientSecret = env('GOOGLE_CLIENT_SECRET');
    $redirectUri = env('GOOGLE_REDIRECT_URI');
    if (!$clientId || !$clientSecret || !$redirectUri) {
        return null;
    }

    $client = new Google_Client();
    $client->setClientId($clientId);
    $client->setClientSecret($clientSecret);
    $client->setRedirectUri($redirectUri);
    $client->setAccessType('offline');
    $client->setPrompt('consent');
    $client->setScopes([
        Google_Service_Calendar::CALENDAR,
        Google_Service_Calendar::CALENDAR_EVENTS,
    ]);

    if (!empty($_SESSION['google_token']) && is_array($_SESSION['google_token'])) {
        $client->setAccessToken($_SESSION['google_token']);
    }

    if ($client->isAccessTokenExpired() && !empty($_SESSION['google_token']['refresh_token'])) {
        $token = $client->fetchAccessTokenWithRefreshToken($_SESSION['google_token']['refresh_token']);
        if (!isset($token['error'])) {
            $_SESSION['google_token'] = array_merge($_SESSION['google_token'], $token);
            $client->setAccessToken($_SESSION['google_token']);
        }
    }

    return $client;
}

function google_calendar_service(): ?Google_Service_Calendar
{
    $client = google_client();
    if (!$client || !$client->getAccessToken()) {
        return null;
    }
    return new Google_Service_Calendar($client);
}
