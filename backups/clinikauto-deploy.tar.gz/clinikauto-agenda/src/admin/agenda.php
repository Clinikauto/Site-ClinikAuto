<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once dirname(__DIR__) . '/api/export_vroomly.php';

$pdo = get_pdo();
$action = $_GET['action'] ?? 'list';

function appointment_exists_on_slot(PDO $pdo, string $dateTime, ?int $ignoreId = null): bool
{
    $sql = 'SELECT id FROM appointments WHERE date = :date AND status != :cancelled';
    $params = ['date' => $dateTime, 'cancelled' => 'cancelled'];
    if ($ignoreId !== null) {
        $sql .= ' AND id != :id';
        $params['id'] = $ignoreId;
    }
    $stmt = $pdo->prepare($sql . ' LIMIT 1');
    $stmt->execute($params);
    return (bool) $stmt->fetchColumn();
}

function sync_google_calendar_from_local(PDO $pdo, array $appointment, string $operation): void
{
    $service = google_calendar_service();
    if (!$service) {
        return;
    }

    $calendarId = env('GOOGLE_CALENDAR_ID', 'primary') ?? 'primary';
    $start = new DateTimeImmutable($appointment['date']);
    $end = $start->modify('+1 hour');

    if ($operation === 'delete' && !empty($appointment['external_event_id'])) {
        try {
            $service->events->delete($calendarId, $appointment['external_event_id']);
            audit_log('google_event_deleted', ['event_id' => $appointment['external_event_id']]);
        } catch (Throwable $exception) {
            audit_log('google_event_delete_error', ['message' => $exception->getMessage()]);
        }
        return;
    }

    $event = new Google_Service_Calendar_Event([
        'summary' => 'ClinikAuto - ' . ($appointment['email'] ?? 'Client'),
        'description' => (string) ($appointment['notes'] ?? ''),
        'status' => $appointment['status'] === 'cancelled' ? 'cancelled' : 'confirmed',
        'start' => ['dateTime' => $start->format(DATE_ATOM), 'timeZone' => 'Europe/Paris'],
        'end' => ['dateTime' => $end->format(DATE_ATOM), 'timeZone' => 'Europe/Paris'],
    ]);

    try {
        if (!empty($appointment['external_event_id'])) {
            $saved = $service->events->update($calendarId, $appointment['external_event_id'], $event);
        } else {
            $saved = $service->events->insert($calendarId, $event);
            $stmt = $pdo->prepare('UPDATE appointments SET external_event_id = :event_id WHERE id = :id');
            $stmt->execute(['event_id' => $saved->id, 'id' => $appointment['id']]);
        }
        audit_log('google_event_synced', ['appointment_id' => $appointment['id'], 'operation' => $operation]);
    } catch (Throwable $exception) {
        audit_log('google_event_sync_error', ['appointment_id' => $appointment['id'], 'message' => $exception->getMessage()]);
    }
}

function appointment_payload_from_db(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare(
        'SELECT a.*, u.email
         FROM appointments a
         LEFT JOIN users u ON u.id = a.client_id
         WHERE a.id = :id LIMIT 1'
    );
    $stmt->execute(['id' => $id]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function admin_list(PDO $pdo): void
{
    $user = require_auth('admin');
    $stmt = $pdo->query(
        "SELECT a.*, u.email
         FROM appointments a
         LEFT JOIN users u ON u.id = a.client_id
         ORDER BY a.date ASC"
    );
    json_response(['appointments' => $stmt->fetchAll(), 'user' => $user]);
}

function available_slots(PDO $pdo): void
{
    require_auth();
    $days = max(1, min(14, (int) ($_GET['days'] ?? 7)));
    $slots = [];

    for ($offset = 0; $offset < $days; $offset++) {
        $date = (new DateTimeImmutable('today +' . $offset . ' day'))->format('Y-m-d');
        foreach (available_time_slots() as $time) {
            $dateTime = $date . ' ' . $time . ':00';
            if (!appointment_exists_on_slot($pdo, $dateTime)) {
                $slots[] = ['date' => $date, 'time' => $time];
            }
        }
    }

    json_response(['slots' => $slots]);
}

function mutate_appointment(PDO $pdo, string $mode): void
{
    $admin = require_auth('admin');
    verify_csrf();
    $body = request_json();

    if ($mode === 'create') {
        $dateTime = normalize_datetime_input((string) ($body['date'] ?? ''), (string) ($body['time'] ?? ''));
        if (appointment_exists_on_slot($pdo, $dateTime)) {
            json_response(['error' => 'Créneau déjà réservé'], 409);
        }

        $stmt = $pdo->prepare('INSERT INTO appointments(date, client_id, status, notes, updated_at) VALUES(:date, :client_id, :status, :notes, CURRENT_TIMESTAMP)');
        $stmt->execute([
            'date' => $dateTime,
            'client_id' => (int) ($body['client_id'] ?? 0) ?: null,
            'status' => in_array(($body['status'] ?? 'pending'), ['pending', 'confirmed', 'cancelled'], true) ? $body['status'] : 'pending',
            'notes' => trim((string) ($body['notes'] ?? '')),
        ]);
        $appointmentId = (int) $pdo->lastInsertId();
        $appointment = appointment_payload_from_db($pdo, $appointmentId);
        if ($appointment) {
            sync_google_calendar_from_local($pdo, $appointment, 'create');
        }
        $export = run_vroomly_export($pdo, 'appointment_create');
        audit_log('appointment_created', ['appointment_id' => $appointmentId, 'by' => $admin['email']]);
        json_response(['message' => 'Rendez-vous ajouté', 'appointment' => $appointment, 'export' => $export], 201);
    }

    $appointmentId = (int) ($body['id'] ?? 0);
    if ($appointmentId <= 0) {
        json_response(['error' => 'Identifiant invalide'], 422);
    }

    if ($mode === 'delete') {
        $appointment = appointment_payload_from_db($pdo, $appointmentId);
        if (!$appointment) {
            json_response(['error' => 'Rendez-vous introuvable'], 404);
        }
        $delete = $pdo->prepare('DELETE FROM appointments WHERE id = :id');
        $delete->execute(['id' => $appointmentId]);
        sync_google_calendar_from_local($pdo, $appointment, 'delete');
        $export = run_vroomly_export($pdo, 'appointment_delete');
        audit_log('appointment_deleted', ['appointment_id' => $appointmentId, 'by' => $admin['email']]);
        json_response(['message' => 'Rendez-vous supprimé', 'export' => $export]);
    }

    $existing = appointment_payload_from_db($pdo, $appointmentId);
    if (!$existing) {
        json_response(['error' => 'Rendez-vous introuvable'], 404);
    }

    $status = (string) ($body['status'] ?? $existing['status']);
    if (!in_array($status, ['pending', 'confirmed', 'cancelled'], true)) {
        json_response(['error' => 'Statut invalide'], 422);
    }

    $dateTime = $existing['date'];
    if (isset($body['date'], $body['time'])) {
        $dateTime = normalize_datetime_input((string) $body['date'], (string) $body['time']);
        if (appointment_exists_on_slot($pdo, $dateTime, $appointmentId)) {
            json_response(['error' => 'Créneau déjà réservé'], 409);
        }
    }

    $stmt = $pdo->prepare(
        'UPDATE appointments
         SET date = :date,
             client_id = :client_id,
             status = :status,
             notes = :notes,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = :id'
    );
    $stmt->execute([
        'date' => $dateTime,
        'client_id' => (int) ($body['client_id'] ?? $existing['client_id']) ?: null,
        'status' => $mode === 'confirm' ? 'confirmed' : $status,
        'notes' => trim((string) ($body['notes'] ?? $existing['notes'] ?? '')),
        'id' => $appointmentId,
    ]);

    $appointment = appointment_payload_from_db($pdo, $appointmentId);
    if ($appointment) {
        sync_google_calendar_from_local($pdo, $appointment, $mode);
    }
    $export = run_vroomly_export($pdo, 'appointment_' . $mode);
    audit_log('appointment_updated', ['appointment_id' => $appointmentId, 'mode' => $mode, 'by' => $admin['email']]);
    json_response(['message' => 'Rendez-vous mis à jour', 'appointment' => $appointment, 'export' => $export]);
}

function google_events(): void
{
    require_auth('admin');
    $service = google_calendar_service();
    if (!$service) {
        json_response(['events' => [], 'connected' => false, 'message' => 'Google Calendar non connecté ou bibliothèque absente']);
    }

    $calendarId = env('GOOGLE_CALENDAR_ID', 'primary') ?? 'primary';
    $events = $service->events->listEvents($calendarId, [
        'maxResults' => 20,
        'singleEvents' => true,
        'orderBy' => 'startTime',
        'timeMin' => (new DateTimeImmutable('today'))->format(DATE_ATOM),
    ]);

    $normalized = [];
    foreach ($events->getItems() as $event) {
        $normalized[] = [
            'id' => $event->getId(),
            'summary' => $event->getSummary(),
            'status' => $event->getStatus(),
            'start' => $event->getStart()?->getDateTime() ?: $event->getStart()?->getDate(),
            'end' => $event->getEnd()?->getDateTime() ?: $event->getEnd()?->getDate(),
        ];
    }

    json_response(['events' => $normalized, 'connected' => true]);
}

function google_add(): void
{
    require_auth('admin');
    $body     = json_decode(file_get_contents('php://input'), true) ?? [];
    $summary  = trim((string)($body['summary'] ?? ''));
    $start    = trim((string)($body['start'] ?? ''));
    $end      = trim((string)($body['end'] ?? ''));
    $desc     = trim((string)($body['description'] ?? ''));

    if ($summary === '' || $start === '' || $end === '') {
        json_response(['error' => 'Champs summary, start et end requis'], 422);
    }

    $service = google_calendar_service();
    if (!$service) {
        json_response(['error' => 'Google Calendar non connecté'], 503);
    }

    $calendarId = env('GOOGLE_CALENDAR_ID', 'primary') ?? 'primary';
    $event = new Google_Service_Calendar_Event([
        'summary'     => $summary,
        'description' => $desc,
        'start'       => ['dateTime' => $start, 'timeZone' => 'Europe/Paris'],
        'end'         => ['dateTime' => $end,   'timeZone' => 'Europe/Paris'],
    ]);

    try {
        $created = $service->events->insert($calendarId, $event);
        audit_log('google_event_added', ['event_id' => $created->getId(), 'summary' => $summary]);
        json_response([
            'message' => 'Événement ajouté dans Google Agenda',
            'event'   => [
                'id'      => $created->getId(),
                'summary' => $created->getSummary(),
                'start'   => $created->getStart()?->getDateTime() ?: $created->getStart()?->getDate(),
                'end'     => $created->getEnd()?->getDateTime()   ?: $created->getEnd()?->getDate(),
            ],
        ]);
    } catch (Throwable $e) {
        audit_log('google_event_add_error', ['message' => $e->getMessage()]);
        json_response(['error' => 'Erreur Google API : ' . $e->getMessage()], 500);
    }
}

function google_update(): void
{
    require_auth('admin');
    $body     = json_decode(file_get_contents('php://input'), true) ?? [];
    $eventId  = trim((string)($body['id'] ?? ''));
    $summary  = trim((string)($body['summary'] ?? ''));
    $start    = trim((string)($body['start'] ?? ''));
    $end      = trim((string)($body['end'] ?? ''));
    $desc     = trim((string)($body['description'] ?? ''));

    if ($eventId === '' || $summary === '' || $start === '' || $end === '') {
        json_response(['error' => 'Champs id, summary, start et end requis'], 422);
    }

    $service = google_calendar_service();
    if (!$service) {
        json_response(['error' => 'Google Calendar non connecté'], 503);
    }

    $calendarId = env('GOOGLE_CALENDAR_ID', 'primary') ?? 'primary';

    try {
        $existing = $service->events->get($calendarId, $eventId);
        $existing->setSummary($summary);
        $existing->setDescription($desc);
        $startObj = new Google_Service_Calendar_EventDateTime();
        $startObj->setDateTime($start);
        $startObj->setTimeZone('Europe/Paris');
        $existing->setStart($startObj);
        $endObj = new Google_Service_Calendar_EventDateTime();
        $endObj->setDateTime($end);
        $endObj->setTimeZone('Europe/Paris');
        $existing->setEnd($endObj);
        $updated = $service->events->update($calendarId, $eventId, $existing);
        audit_log('google_event_updated', ['event_id' => $eventId, 'summary' => $summary]);
        json_response([
            'message' => 'Événement mis à jour',
            'event'   => [
                'id'      => $updated->getId(),
                'summary' => $updated->getSummary(),
                'start'   => $updated->getStart()?->getDateTime() ?: $updated->getStart()?->getDate(),
                'end'     => $updated->getEnd()?->getDateTime()   ?: $updated->getEnd()?->getDate(),
            ],
        ]);
    } catch (Throwable $e) {
        audit_log('google_event_update_error', ['message' => $e->getMessage()]);
        json_response(['error' => 'Erreur Google API : ' . $e->getMessage()], 500);
    }
}

function google_delete(): void
{
    require_auth('admin');
    $body    = json_decode(file_get_contents('php://input'), true) ?? [];
    $eventId = trim((string)($body['id'] ?? ''));

    if ($eventId === '') {
        json_response(['error' => 'Champ id requis'], 422);
    }

    $service = google_calendar_service();
    if (!$service) {
        json_response(['error' => 'Google Calendar non connecté'], 503);
    }

    $calendarId = env('GOOGLE_CALENDAR_ID', 'primary') ?? 'primary';

    try {
        $service->events->delete($calendarId, $eventId);
        audit_log('google_event_deleted_admin', ['event_id' => $eventId]);
        json_response(['message' => 'Événement supprimé de Google Agenda']);
    } catch (Throwable $e) {
        audit_log('google_event_delete_admin_error', ['message' => $e->getMessage()]);
        json_response(['error' => 'Erreur Google API : ' . $e->getMessage()], 500);
    }
}

switch ($action) {
    case 'list':
        admin_list($pdo);
        break;
    case 'slots':
        available_slots($pdo);
        break;
    case 'create':
        mutate_appointment($pdo, 'create');
        break;
    case 'update':
        mutate_appointment($pdo, 'update');
        break;
    case 'delete':
        mutate_appointment($pdo, 'delete');
        break;
    case 'confirm':
        mutate_appointment($pdo, 'confirm');
        break;
    case 'google-events':
        google_events();
        break;
    case 'google-add':
        google_add();
        break;
    case 'google-update':
        google_update();
        break;
    case 'google-delete':
        google_delete();
        break;
    default:
        json_response(['error' => 'Action agenda inconnue'], 404);
}
