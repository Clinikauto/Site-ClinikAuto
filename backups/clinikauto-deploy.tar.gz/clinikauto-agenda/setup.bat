@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
echo.
echo ============================================================
echo  ClinikAuto Agenda — Script d'initialisation Windows
echo ============================================================
echo.

REM ---------- Vérification PHP ----------
where php >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] PHP n'est pas installe ou pas dans le PATH.
    echo  Telechargez PHP 8.1+ sur https://windows.php.net/download/
    exit /b 1
)
for /f "tokens=*" %%v in ('php -r "echo PHP_VERSION;"') do set PHP_VERSION=%%v
echo [OK] PHP %PHP_VERSION% detecte.

REM ---------- Vérification extensions PHP ----------
php -r "exit(extension_loaded('pdo_sqlite') ? 0 : 1);" >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] Extension PHP pdo_sqlite manquante. Activez-la dans php.ini.
    exit /b 1
)
echo [OK] Extension pdo_sqlite presente.

php -r "exit(extension_loaded('openssl') ? 0 : 1);" >nul 2>&1
if %errorlevel% neq 0 (
    echo [AVERTISSEMENT] Extension openssl non detectee. Requise pour JWT et HTTPS.
)

REM ---------- Composer ----------
where composer >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Composer non trouve dans le PATH. Verification de composer.phar local...
    if not exist "composer.phar" (
        echo [INFO] Telechargement de Composer...
        php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
        php composer-setup.php --quiet
        del composer-setup.php 2>nul
        if not exist "composer.phar" (
            echo [ERREUR] Impossible d'obtenir Composer. Installez-le depuis https://getcomposer.org/
            exit /b 1
        )
        set COMPOSER_CMD=php composer.phar
    ) else (
        set COMPOSER_CMD=php composer.phar
    )
) else (
    set COMPOSER_CMD=composer
)
echo [OK] Composer disponible.

REM ---------- Fichier .env ----------
if not exist ".env" (
    if exist ".env.example" (
        copy ".env.example" ".env" >nul
        echo [OK] Fichier .env cree depuis .env.example.
        echo [IMPORTANT] Editez .env pour renseigner vos cles API et secrets.
    ) else (
        echo [AVERTISSEMENT] .env.example introuvable. Creez .env manuellement.
    )
) else (
    echo [OK] Fichier .env deja present.
)

REM ---------- Dossiers data / logs ----------
if not exist "src\data" mkdir "src\data"
if not exist "src\data\exports" mkdir "src\data\exports"
if not exist "src\data\backups" mkdir "src\data\backups"
if not exist "src\logs" mkdir "src\logs"
echo [OK] Dossiers src/data et src/logs crees.

REM ---------- Installation des dependances ----------
echo.
echo [INFO] Installation des dependances Composer...
%COMPOSER_CMD% install --no-interaction --prefer-dist
if %errorlevel% neq 0 (
    echo [ERREUR] composer install a echoue.
    exit /b 1
)
echo [OK] Dependances installees.

REM ---------- Initialisation de la base SQLite ----------
echo.
echo [INFO] Initialisation de la base de donnees SQLite...
php setup_db.php
if %errorlevel% neq 0 (
    echo [ERREUR] Initialisation base de donnees echouee.
    exit /b 1
)
echo [OK] Base de donnees initialisee dans src/data/agenda.db.

echo.
echo ============================================================
echo  Installation terminee !
echo  Lancez un serveur PHP local :
echo    php -S localhost:8080 -t src/public
echo  Puis ouvrez : http://localhost:8080
echo ============================================================
echo.
endlocal
