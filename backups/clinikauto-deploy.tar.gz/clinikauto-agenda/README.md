# ClinikAuto Agenda

Projet PHP pour la gestion des rendez-vous ClinikAuto avec :

- session admin securisee
- gestion locale SQLite des rendez-vous
- synchronisation Google Calendar via OAuth 2.0
- export Vroomly en CSV/JSON avec journalisation

Structure principale :

- src/admin : interface et endpoints admin
- src/client : authentification et espace client
- src/public : pages publiques
- src/api : exports et synchronisations externes
- src/data : base SQLite et credentials locaux
- src/logs : journaux applicatifs
- docs : documentation technique

Voir docs/INSTALL.md pour l'installation.
