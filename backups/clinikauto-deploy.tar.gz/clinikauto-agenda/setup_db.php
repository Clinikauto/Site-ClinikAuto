<?php
/**
 * setup_db.php — Initialisation de la base SQLite pour ClinikAuto Agenda
 * Exécuter depuis la racine du projet : php setup_db.php
 */
declare(strict_types=1);

$dbPath = __DIR__ . '/src/data/agenda.db';

// Créer les répertoires si nécessaire
foreach (['src/data', 'src/data/exports', 'src/data/backups', 'src/logs'] as $dir) {
    $fullPath = __DIR__ . '/' . $dir;
    if (!is_dir($fullPath) && !mkdir($fullPath, 0755, true)) {
        fwrite(STDERR, "[ERREUR] Impossible de créer le dossier $fullPath\n");
        exit(1);
    }
}

try {
    $pdo = new PDO('sqlite:' . $dbPath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    $pdo->exec("PRAGMA journal_mode=WAL;");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            email       TEXT    UNIQUE NOT NULL,
            password    TEXT    NOT NULL,
            role        TEXT    NOT NULL DEFAULT 'client',
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS appointments (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id           INTEGER REFERENCES users(id) ON DELETE SET NULL,
            date                TEXT    NOT NULL,
            status              TEXT    NOT NULL DEFAULT 'pending',
            notes               TEXT,
            external_event_id   TEXT,
            created_at          TEXT    NOT NULL DEFAULT (datetime('now')),
            updated_at          TEXT    NOT NULL DEFAULT (datetime('now'))
        );
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS audit_logs (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            action     TEXT NOT NULL,
            context    TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS site_settings (
            key        TEXT PRIMARY KEY,
            value      TEXT,
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
    ");

    // Compte admin par défaut (si absent)
    // Mot de passe par défaut : Admin1234!  — À CHANGER dans .env puis relancer
    $envFile = __DIR__ . '/.env';
    $adminEmail    = 'admin@clinikauto.local';
    $adminPassword = 'Admin1234!';

    if (file_exists($envFile)) {
        foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            if (str_starts_with($line, 'ADMIN_EMAIL=')) {
                $adminEmail = trim(substr($line, strlen('ADMIN_EMAIL=')), " \t\"'");
            }
            if (str_starts_with($line, 'ADMIN_PASSWORD=')) {
                $adminPassword = trim(substr($line, strlen('ADMIN_PASSWORD=')), " \t\"'");
            }
        }
    }

    $existing = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $existing->execute([$adminEmail]);
    if (!$existing->fetch()) {
        $hash = password_hash($adminPassword, PASSWORD_BCRYPT, ['cost' => 12]);
        $stmt = $pdo->prepare("INSERT INTO users (email, password, role) VALUES (?, ?, 'admin')");
        $stmt->execute([$adminEmail, $hash]);
        echo "[OK] Compte admin créé : $adminEmail\n";
    } else {
        echo "[OK] Compte admin déjà présent : $adminEmail\n";
    }

    echo "[OK] Base de données initialisée : $dbPath\n";
    exit(0);

} catch (Throwable $e) {
    fwrite(STDERR, "[ERREUR] " . $e->getMessage() . "\n");
    exit(1);
}
